<?php

// WordPress view bootstrapper
define('WP_USE_THEMES', true);
require(dirname(__FILE__) . '/wp/wp-blog-header.php');
